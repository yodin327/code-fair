// index.js
const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

app.use(cors());
app.use(express.json()); // JSON 형태의 요청 본문을 해석하기 위해 추가

let coordinates = []; // Define coordinates array to store received coordinates

app.post('/log-coordinates', (req, res) => {
    const newCoordinates = req.body;
    coordinates = newCoordinates; // Update coordinates with new data
    console.log('Received coordinates:', coordinates);
    res.send('Coordinates received');
});

function transformCoordinates(coords) {
    return coords.map(point => ({
        x: point.x >= 0.5 ? 'a' : 'b',
        y: point.y >= 0.5 ? 'a' : 'b'
    }));
}

app.get('/', (req, res) => {
    const transformedCoordinates = transformCoordinates(coordinates);
    res.json(transformedCoordinates); // Send transformed coordinates as JSON response
});

// 서버 시작
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});