document.addEventListener('DOMContentLoaded', function () {
    const gridCanvas = document.getElementById('gridCanvas');
    const ctx = gridCanvas.getContext('2d');

    gridCanvas.width = 800;
    gridCanvas.height = 600;

    // 에어컨 중심 좌표 설정
    const airconCenterX = 423;
    const airconCenterY = 300;

    // 사등분하는 눈금선 그리기
    function drawGrid() {
        ctx.clearRect(0, 0, gridCanvas.width, gridCanvas.height);
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.2)'; // 희미한 색상
        ctx.lineWidth = 1;

        // 세로선
        ctx.beginPath();
        ctx.moveTo(airconCenterX, 0);
        ctx.lineTo(airconCenterX, gridCanvas.height);
        ctx.stroke();

        // 가로선
        ctx.beginPath();
        ctx.moveTo(0, airconCenterY);
        ctx.lineTo(gridCanvas.width, airconCenterY);
        ctx.stroke();
    }

    drawGrid();

    let points = [];

    gridCanvas.addEventListener('click', function (event) {
        if (points.length < 4) {
            const rect = gridCanvas.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const y = event.clientY - rect.top;

            points.push({ x: x, y: y });

            // 점 그리기
            ctx.fillStyle = 'red';
            ctx.beginPath();
            ctx.arc(x, y, 5, 0, 2 * Math.PI);
            ctx.fill();

            var send_x;
            var send_y;

            // 클릭한 좌표 변환
            if (x > airconCenterX) {
                send_x = Math.round((x - airconCenterX) * 100 / 377) / 100;
            } else {
                send_x = Math.round((x - airconCenterX) * 100 / 423) / 100;
            }
            send_y = Math.round((y - airconCenterY) * 100 / 300) / 100;

            // 좌표를 HTML 요소로 추가
            const xposElem = document.getElementById(`xpos${points.length}`);
            const yposElem = document.getElementById(`ypos${points.length}`);
            xposElem.textContent = send_x;
            yposElem.textContent = send_y;

            // 좌표가 제대로 설정되었는지 확인 (디버깅용)
            console.log(`Point ${points.length}: (${send_x}, ${send_y})`);
            console.log(`HTML Element xpos${points.length}: ${xposElem.textContent}`);
            console.log(`HTML Element ypos${points.length}: ${yposElem.textContent}`);
            
            if (points.length === 4) {
                drawPolygon();
                sendCoordinates();
            }
        }
    });

    function drawPolygon() {
        ctx.fillStyle = 'rgba(255, 0, 0, 0.2)'; // 불투명한 빨간색
        ctx.strokeStyle = 'rgba(255, 0, 0, 1)'; // 선 색상
        ctx.lineWidth = 2;

        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) {
            ctx.lineTo(points[i].x, points[i].y);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
    }
    
    function sendCoordinates() {
        const coordinates = [];
        for (let i = 1; i <= 4; i++) {
            const x = document.getElementById(`xpos${i}`).textContent;
            const y = document.getElementById(`ypos${i}`).textContent;
            coordinates.push({ x: parseFloat(x), y: parseFloat(y) });
        }

        fetch('http://localhost:3000/log-coordinates', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(coordinates),
        })
        .then(response => response.text())
        .then(data => {
            console.log('Server response:', data);
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    }
});


